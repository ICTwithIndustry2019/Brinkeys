#pragma once

#define _int int
#define _float float
#define _llint long long int
#define _double double
#define _bool bool
